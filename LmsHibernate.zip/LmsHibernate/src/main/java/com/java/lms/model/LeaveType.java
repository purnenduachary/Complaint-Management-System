package com.java.lms.model;

public enum LeaveType {
	ML,EL,PL
}
