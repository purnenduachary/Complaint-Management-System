package com.java.lms.model;

public enum LeaveStatus {
	PENDING, APPROVED, REJECTED
}