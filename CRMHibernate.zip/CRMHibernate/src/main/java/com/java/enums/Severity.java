package com.java.enums;

public enum Severity {

	LOW, MEDIUM, HIGH
}
