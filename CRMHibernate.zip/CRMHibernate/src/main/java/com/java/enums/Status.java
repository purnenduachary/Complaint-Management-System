package com.java.enums;

public enum Status {

	PENDING, INPROGRESS, RESOLVED
}
