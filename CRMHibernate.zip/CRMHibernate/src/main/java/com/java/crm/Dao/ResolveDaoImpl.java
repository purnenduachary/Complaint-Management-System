package com.java.crm.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.java.crm.model.Resolve;
import com.java.enums.Status;

public class ResolveDaoImpl implements ResolveDao{
	
	    SessionFactory sf;
	    Session session;

	    @Override
	    public String addResolve(Resolve resolve) {
	        sf = new AnnotationConfiguration().configure().buildSessionFactory();
	        session = sf.openSession();
	        Transaction tx = session.beginTransaction();

	        session.save(resolve);

	        String hql = "UPDATE Complaint SET status = :status WHERE complaintId = :complaintId";
	        Query query = session.createQuery(hql);
	        query.setParameter("status", Status.RESOLVED);  
	        query.setParameter("complaintId", resolve.getComplaintID());

	        query.executeUpdate();

	        tx.commit();

	        session.close();

	        return "Resolve added and status updated successfully!";
	    }


	    @Override
	    public List<Resolve> getAllResolves() {
	        sf = new AnnotationConfiguration().configure().buildSessionFactory();
	        session = sf.openSession();

	        List<Resolve> resolveList = session.createQuery("from Resolve").list();

	        for (Resolve r : resolveList) {
	            if (r.getComplaintDate() != null && r.getResolveDate() != null) {
	                long tat = (r.getResolveDate().getTime() - r.getComplaintDate().getTime()) / (1000 * 60 * 60 * 24);
	                r.setTat(tat);
	            }
	        }

	        return resolveList;
	    }

	    @Override
	    public Resolve getResolveByComplaintId(String complaintId) {
	        sf = new AnnotationConfiguration().configure().buildSessionFactory();
	        session = sf.openSession();

	        Query q = session.createQuery("from Resolve where complaintID = :cid");
	        q.setParameter("cid", complaintId); 

	        Resolve r = (Resolve) q.uniqueResult();

	        if (r != null && r.getComplaintDate() != null && r.getResolveDate() != null) {
	            long tat = (r.getResolveDate().getTime() - r.getComplaintDate().getTime()) / (1000 * 60 * 60 * 24);
	            r.setTat(tat);
	        }

	        return r;
	    }

	}

